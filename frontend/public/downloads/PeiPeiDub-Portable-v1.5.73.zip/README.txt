Huong dan cai dat PeiPei Dub Studio v1.5.73
Chay file PeiPeiDub-Setup-v1.5.73.exe de chon o dia cai dat (C:, D:, E:...) va bat dau su dung.
