Huong dan su dung PeiPei Dub Studio v1.5.73
1. Nhap dup file PeiPeiDub-Setup-v1.5.73.exe de chay truc tiep khong can cai dat.
2. Sao chep ma HWID de kich hoat tren Web Admin Portal.
