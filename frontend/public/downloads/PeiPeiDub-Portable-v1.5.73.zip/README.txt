Huong dan cai dat PeiPei Dub Studio v1.5.73
1. Chay file PeiPeiDub.exe
2. Nhap HWID vao Admin Web Portal de lay ma License.
